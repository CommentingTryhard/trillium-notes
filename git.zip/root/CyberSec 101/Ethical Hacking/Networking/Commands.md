# Commands
ifconfig – find IPs of computers