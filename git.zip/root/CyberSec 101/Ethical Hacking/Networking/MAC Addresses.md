# MAC Addresses
**OSI - LAYER 2**

MAC – Media Access Control

Network Switches communicate over this layer & MAC addresses

**aa : bb : cc : dd : ee : ff**

aa : bb : cc – refers to vendor identifier

dd : ee : ff – network interface controller specific identifiers

format is in hexadecimal