# OSI Models
Plz

LAYER 1: Physical Layer

cables, cables, cables, pure machine code

Do

LAYER 2: Data Layer

Switches, MAC Addresses

Not

LAYER 3: Network Layer

IP Addresses, Routing

Throw

LAYER 4: Transport Layer

TCP/UDP

Sausage

LAYER 5: Session Layer

Session Management

Pizza

LAYER 6: Presentation Layer

Media, WMV, JPEG, MOV

Away

LAYER 7: Application Layer

HTTP, SMTP