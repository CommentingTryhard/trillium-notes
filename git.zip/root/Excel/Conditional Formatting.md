# Conditional Formatting
Conditional formatting

*   ALWAYS generate a new rule based on a custom formula. 
*   you DO not need to use “=IF”
*   You only set a value for if conditions are true.
*   The cells are automatically set as absolute, thus do watch out.
*   $col$row = locked both row and column, $ affects the attribute immediately after it.