# Formulas
**SUM**

*   A range of cells can be inputted to find the sum of all arguments
*   Only numbers can be inputted within.

**AVERAGE**

*   Average outputs the mean number of all arguments.
*   Only numbers can be inputted within

**MIN - MAX**

*   Find the minimum or maximum value within the range of arguments

**COUNT**

*   COUNTA
*   COUNTIF(S)
*   COUNTBLANK

**VLOOKUP**

*   VLOOKUP(lookup value, table array, column index number)
*   lookupvalue is the variable the searcher uses to find the value, outside of the reference table
*   table array defines the reference table
*   col\_inx\_nums defines which column the ref table searches from

**HLOOKUP**

*   Same as vlookup, however searches among the reference table in a horizontal manner.